import requests

PLANTNET_API_KEY = "2b10P4sZ4BOjDAkV56zYhM1Ie"  

def identify_species(image_path):
    # URL with API key in the URL itself
    url = f"https://my-api.plantnet.org/v2/identify/all?api-key={PLANTNET_API_KEY}"

    with open(image_path, "rb") as image_file:
        files = {"images": image_file}
        response = requests.post(url, files=files)

    if response.status_code == 200:
        data = response.json()
        try:
            species = data['results'][0]['species']['scientificNameWithoutAuthor']
            return species
        except Exception:
            raise Exception("Could not extract species from response.")
    else:
        raise Exception(f"PlantNet API error: {response.status_code} {response.text}")
