# Import functions from the other files
from plantnet_api import identify_species
from gpt_analysis import generate_insight, generate_script

def main():
    # Print welcome message
    print("🌱 BNGbot - Biodiversity Assistant 🌿")
    
    # Ask user to input the image file path
    image_path = input("Enter the file path for your plant image: ").strip()

    try:
        # Identify plant species using PlantNet API
        species = identify_species(image_path)
        print(f"\n✅ Identified species: {species}")

        # Ask GPT-4o to generate ecological insights
        print("\n🧠 Generating ecological insights...")
        insights = generate_insight(species)
        print("\n📋 Ecological Summary:\n", insights)

        # Ask GPT-4o to generate a biodiversity analysis script
        print("\n🧪 Generating biodiversity analysis script...")
        script = generate_script(species)
        print("\n🖥️ Python Analysis Script:\n", script)

    except Exception as e:
        # Catch and print any errors
        print(f"\n❌ An error occurred: {e}")

# Run the main function only if this script is executed directly
if __name__ == "__main__":
    main()
