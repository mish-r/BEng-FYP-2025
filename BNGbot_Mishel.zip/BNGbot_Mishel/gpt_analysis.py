from openai import OpenAI

# Authenticate with GPT-4o via GitHub Marketplace using GitHub token
client = OpenAI(
    base_url="https://models.inference.ai.azure.com",
    api_key="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"  
)

def generate_insight(species_name):
    # Create a prompt to ask GPT-4o for ecological information about the species
    prompt = (
        f"Provide an ecological summary for the plant species '{species_name}', "
        "including habitat, biodiversity role, conservation status, and interesting facts."
    )

    # Send the prompt to GPT-4o
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=600
    )

    # Return the generated content
    return response.choices[0].message.content.strip()

def generate_script(species_name):
    # Create a prompt to ask GPT-4o to generate a biodiversity analysis script
    prompt = (
        f"Write a Python script using pandas and matplotlib to analyze biodiversity "
        f"data for '{species_name}'. Include species frequency and a bar chart with sample data."
    )

    # Send the prompt to GPT-4o
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=700
    )

    # Return the generated script
    return response.choices[0].message.content.strip()
