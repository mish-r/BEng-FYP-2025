import unittest
from unittest.mock import patch, MagicMock, mock_open
from gpt_analysis import generate_insight, generate_script
from plantnet_api import identify_species

class TestBNGCbot_Mishel_System(unittest.TestCase):

    # Test for valid generate_insight
    @patch('gpt_analysis.client.chat.completions.create')
    def test_generate_insight_system(self, mock_create):
        # Mocking the GPT response for ecological insights
        mock_response = MagicMock()
        mock_response.choices[0].message.content = "This is an ecological summary."
        mock_create.return_value = mock_response

        result = generate_insight("Acacia")
        self.assertEqual(result, "This is an ecological summary.")

    # Test for valid generate_script
    @patch('gpt_analysis.client.chat.completions.create')
    def test_generate_script_system(self, mock_create):
        # Mocking the GPT response for script generation
        mock_response = MagicMock()
        mock_response.choices[0].message.content = "This is a Python script."
        mock_create.return_value = mock_response

        result = generate_script("Acacia")
        self.assertEqual(result, "This is a Python script.")

    # Test for valid identify_species (system test with image file handling)
    @patch('plantnet_api.requests.post')
    @patch('builtins.open', new_callable=mock_open)  # Mock open for file reading
    def test_identify_species_system(self, mock_open, mock_post):
        # Mocking the open() function to simulate reading a file
        mock_open.return_value.read.return_value = b"fake image data"
        
        # Simulate a successful response from PlantNet API
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'results': [{
                'species': {
                    'scientificNameWithoutAuthor': 'Acacia',
                    'scientificName': 'Acacia'
                }
            }]
        }
        mock_post.return_value = mock_response

        result = identify_species("test_image_path.jpg")
        self.assertEqual(result, "Acacia")

    # Test for invalid identify_species (API error handling)
    @patch('plantnet_api.requests.post')
    @patch('builtins.open', new_callable=mock_open)  # Mock open for file reading
    def test_identify_species_invalid_system(self, mock_open, mock_post):
        # Mocking the open() function to simulate reading a file
        mock_open.return_value.read.return_value = b"fake image data"
        
        # Simulating an error response from PlantNet API
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.text = "Bad request"
        mock_post.return_value = mock_response
        
        with self.assertRaises(Exception):
            identify_species("test_image_path.jpg")

if __name__ == '__main__':
    unittest.main()
